class Area{
    int l,b;

    //constructor

    Area(int l,int b)
    {
        this.l=l;
        this.b=b;
    }
    public void getArea()
    {
        int area = l*b;
        System.out.println("area = "+area);
    }
}

public class Mainen {
    public static void main(String[] args) {
       Area a = new Area(5, 6) ;
       a.getArea();
    }
}
