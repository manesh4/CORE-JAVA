class Employee{
    //data hiding
    private int empid;

    //setter method
    public void setEmpid(int eid)
    {
        empid = eid;
    }

    public int getEmpid()
    {
        return empid;
    }
//encapsulation
}
public class CompanyEn {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setEmpid(101);
        System.out.println(e.getEmpid());
    }
}
