abstract class Vehical
{
    abstract void start();   
}
class Car extends Vehical{
    void start()
    {
        System.out.println("start with key...!");
    }
}
class Scooter extends Vehical{
    void start()
    {
        System.out.println("start with kick...!");
    }
}
public class Abs {
    public static void main(String[] args) {
        Car c = new Car();
        c.start();
        Scooter s = new Scooter();
        s.start();
    }
}
