class Square{
    int sq(int n)
    {
        return n*n;
    }
}
class Cube extends Square{
    int sq(int n)
    {
        return n*n*n;
    }
}
public class Overriding {
    public static void main(String[] args) {
        Square obj = new Square();
        System.out.println(obj.sq(2));
        Cube c = new Cube();
        System.out.println(c.sq(2));
    }
}
