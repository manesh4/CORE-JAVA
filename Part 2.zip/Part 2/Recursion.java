public class Recursion {

    //continues recursion(infinite times)
    // static void show()
    // {
    //     System.out.println("hello");
    //     show();
    // }

    

    //continues recursion(finite times)

    // static int no=0;
    // static void show()
    // {
    //     no++;
    //     if(no<=5)
    //     {
    //         System.out.println("hello" + no);
    //         show();
    //     }
       
    // }


    //factorial using recursion

    // static int factorial(int n)
    // {
    //     if(n==1 || n==0)
    //     {
    //         return 1;
    //     }
    //     else{
    //         return n*(factorial(n-1));
    //     }
    // }

    //print 5 to 1 no's

    // static void printNumbers(int n)
    // {
    //     if(n==0)
    //     {
    //         return;
    //     }
    //     System.out.println(n);
    //     printNumbers(n-1);
    // }

    //print 1 to 5
    // static void printNumbers(int n)
    // {
    //     if(n==6)
    //     {
    //         return;
    //     }
    //     System.out.println(n);
    //     printNumbers(n+1);
    // }
    public static void main(String[] args) {

        // printNumbers(1);

        // System.out.println("factorial of 5 is = "+factorial(5));
        
        // show();
    }
}
