public class Exception5 {

    public static void square(int n)
    {
        if(n<1)
        {
            throw new ArithmeticException("plz check no is negative");
        }
        else{
            System.out.println("square is = "+(n*n));
        }
    }
    public static void main(String[] args) {
        
        // square(2);
        square(-2);
    }
}
