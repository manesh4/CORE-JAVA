public class Methods {

    //instance method
    // public void show()
    // {
    //     System.out.println("this is show method");
    // }

    // public static void display()
    // {
    //     System.out.println("this is static method");
    // }
    public void add(int a, int b)
    {
         System.out.println("addition = "+(a+b));
    }
    public int square(int n)
    {
        return n*n;
    }
    public static void main(String[] args) {
        
        //creating objects;
        // Methods m = new Methods();
        // m.show();

         // display();
    // MyClass.display();

    Methods m = new Methods();
     m.add(10,20);
     int result = m.square(2);
      System.out.println("square = "+result);
    }

}
