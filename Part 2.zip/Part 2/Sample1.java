// default constructor
public class Sample1{
    int i;
    String s;
    
  public static void main(String[] args) {
        
    Sample1 cs = new Sample1();

    System.out.println(cs.i + " "+cs.s);
  }
}


// No - argument constructor
// public class Sample1{

//     Sample1()
//     {
//         System.out.println("no argument construcotr is called");
//     }
//   public static void main(String[] args) {
        
//     Sample1 cs = new Sample1();
//   }
// }


//parameterised constructor

// public class Sample1{
    
//     // Sample1(int a)
//     // {
//     //     System.out.println("parameterised constructor called");
//     // }
//     Sample1(String str)
//     {
//         System.out.println("parameterised constructor called");
//     }
//   public static void main(String[] args) {
        
//     Sample1 cs = new Sample1("java");

//   }
// }




