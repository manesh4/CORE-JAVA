public class Exception4 {
    public static void main(String[] args) {
        try{
            // System.out.println(100/0);
            System.out.println(100/5);
        }
        catch(ArithmeticException e)
        {
            System.out.println("this is arithmetic exception");
        }
        finally{
            System.out.println("i m always executed");
        }
    }
}
