public class Exception1 {
    public static void main(String[] args) {
        try
        {
            int no = 100/0;
        }
        catch(ArithmeticException e)
        {
            System.out.println(e);
        }
        System.out.println(50/2);
    }
}
