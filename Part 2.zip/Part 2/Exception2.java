public class Exception2 {
    public static void main(String[] args) {
        int i=50,j=0,no;
        try{
            no = i/j;
        }
        catch(ArithmeticException e)
        {
            System.out.println(i/(j+2));
        }
    }
}
