public class Employee {

    String name;
    int id;

    // Employee(String fname , int eid)
    // {
    //    this.name = fname; 
    //    this.id = eid;
    // }
    // Employee(String name , int id)
    // {
    //    this.name = name; 
    //    this.id = id;
    // }
    // public static void main(String[] args) {
        
    //     Employee e1 = new Employee("prem", 101);

    //     System.out.println("Emplyee1 = "+e1.name+" "+e1.id);

    //     Employee e2 = new Employee("kumar", 102);

    //     System.out.println("Emplyee2 = "+e2.name+" "+e2.id);

    // }
}
