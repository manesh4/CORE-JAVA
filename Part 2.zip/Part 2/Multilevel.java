class Animal
{
    void eat()
    {
        System.out.println("animals are eating..!");
    }
}

class Dog extends Animal{
    void sound()
    {
        System.out.println("Dog is sounding..!");
    }
}

class Cat extends Dog{
    void soundWeep()
    {
        System.out.println("cat is weeping...!");
    }
    
}
public class Multilevel {
    public static void main(String[] args) {
        
        Cat c  = new Cat();

        c.soundWeep();
        c.sound();
        c.eat();
    }
}
