public class Recur {

    public static void display(int n)
    {
        //base condition
        if(n==0)
        {
            return;
        }

        System.out.println(n);
        display(n-1);
    }
    public static void main(String[] args) {
        display(10);
    }
}
