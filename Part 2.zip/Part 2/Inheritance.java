//single inheritance

class Base{
    void show()
    {
        System.out.println("this is base class show method");
    }
}
public class Inheritance extends Base{

    void display()
    {
        System.out.println("this is derived class display method");
    }
    public static void main(String[] args) {
        Inheritance obj1 = new Inheritance();

        obj1.display();
        obj1.show();

    }
}
