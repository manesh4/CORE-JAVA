interface Lang{
    void getName(String name);
}
class Program implements Lang{
    public void getName(String name)
    {
        System.out.println("current language = "+name);
    }
    
}
public class Maininterface {
    public static void main(String[] args) {
        Program p = new Program();
        p.getName("Java");
    }
}
