public class Polymorphism {

    // method overloading 
    static int Multi(int x, int y)
    {
        return x*y;
    }
    static double Multi(double x, double y)
    {
        return x*y;
    }

    // static int Multi(int x, int y,int z)
    // {
    //     return x*y*z;
    // }

    // ----end of static poly-----


    public static void main(String[] args) {
        
        System.out.println(Polymorphism.Multi(4, 6));
        System.out.println(Polymorphism.Multi(4.2, 6.2));
        // System.out.println(Polymorphism.Multi(2, 4,6));
    }
}
