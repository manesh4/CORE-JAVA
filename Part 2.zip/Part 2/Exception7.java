public class Exception7 {
    public static int divide() throws ArithmeticException
    {
        throw new ArithmeticException("throwing exception plz check code");
    }
    public static void main(String[] args) {
        try{
            divide();
        }
        catch(ArithmeticException e)
        {
            System.out.println("caught in main method");
        }

    }
}
