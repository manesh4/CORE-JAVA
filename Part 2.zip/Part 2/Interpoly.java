interface Polygon
{
    void getArea(int l, int b);
}
class Rect implements Polygon
{
    public void getArea(int l, int b)
    {
        System.out.println("area of rect = "+(l*b));
    }
}
public class Interpoly {
    public static void main(String[] args) {
        Rect r = new Rect();
        r.getArea(5, 6);
    }
}
