class Animal{
    void eat()
    {
        System.out.println("animals are eating..");
    }
}
class Dog extends Animal{
    void bark()
    {
        System.out.println("dog is barking");
    }
}
class Cat extends Animal{
    void weep()
    {
        System.out.println("cat is weeping");
    }
}
public class Sample2 {
    public static void main(String[] args) {
        Dog d = new Dog();
       
        d.eat();
        Cat c  = new Cat();
        c.eat();
       
    }
}
