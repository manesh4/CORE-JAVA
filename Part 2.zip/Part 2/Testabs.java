abstract class Bank{
    abstract int interest();
}
class Icici extends Bank{
    int interest()
    {
        return 6;
    }
}
class Sbi extends Bank{
    int interest()
    {
        return 7;
    }
}
public class Testabs {
    public static void main(String[] args) {

        Icici obj1 = new Icici();
        System.out.println("Rate of itnerest  = "+obj1.interest()+"%");
        Sbi obj2 = new Sbi();
        System.out.println("Rate of itnerest  = "+obj2.interest()+"%");
    }
}
