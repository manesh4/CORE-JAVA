import java.io.*;

public class FileStream1 {
    public static void main(String[] args) {
      try{
        byte arr[] = {11,21,3,40,5};
        OutputStream os = new FileOutputStream("sample.txt");
        for(int i=0;i<arr.length;i++)
        {
            //write
            os.write(arr[i]);
        }
        os.close();
        InputStream in = new FileInputStream("sample.txt");
        int size = in.available();
        for(int i=0;i<size;i++)
        {
            System.out.println((char)in.read()+" ");
        }
        in.close();
      } 
      catch(IOException e)
      {
        System.out.println("its exception err");
      } 
    }
}
