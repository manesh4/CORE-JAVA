import java.util.LinkedHashSet;
import java.util.Set;

public class Linkedset {
    public static void main(String[] args) {
        
        Set<String> set = new LinkedHashSet<>();


        set.add("this");
        set.add("is");
        set.add("set");
        set.add("in");
        set.add("java");

        System.out.println(set);
    }
}
