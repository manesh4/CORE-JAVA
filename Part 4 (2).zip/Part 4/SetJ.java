import java.util.*;
public class SetJ {
    public static void main(String[] args) {
        Set<String> set = new HashSet<String>();

        set.add("this");
        set.add("is");
        set.add("set");
        set.add("in");
        set.add("java");
        System.out.println(set);
    }
}
