import java.util.*;
public class Mapping {
    public static void main(String[] args) {
        Map<String,Integer> mp = new HashMap<String,Integer>();

        mp.put("A", 11);
        mp.put("B", 12);
        mp.put("C", 13);
        mp.put("D", 14);

        // System.out.println(mp);

        //traversing using for each loop
        for(Map.Entry<String, Integer> m:mp.entrySet())
        {
          System.out.print(m.getKey()+":");  
          System.out.println(m.getValue());
        }
    }
}
