import java.io.*;

public class Test {
    public static void main(String[] args) throws IOException{
    
        byte con[] = "this is byte to learn bytestream".getBytes();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(con);
        inputStream.read(con);

        File newFile = new File("D:/Java All/Java Full Stack/Core Java/Part 4/demo1.txt");
        FileOutputStream outputStream = new FileOutputStream(newFile);
        outputStream.write(con);
    }
}
