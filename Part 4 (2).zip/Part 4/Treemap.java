import java.util.*;
public class Treemap {
    public static void main(String[] args) {
        Map<String, Integer> map = new TreeMap<>();

        // TreeMap<String,Integer> mp = new TreeMap<>();

        map.put("India", 120);
        map.put("USA", 130);
        map.put("China", 150);

        //iteration

        for(Map.Entry<String,Integer> i : map.entrySet()){
            System.out.print(i.getKey()+" : ");
            System.out.println(i.getValue());
        }

    }
}
