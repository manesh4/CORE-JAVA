import java.io.*;
import java.util.*;

class Movie implements Comparable<Movie>
{
    private double rating;
    private String name;
    private int year;

    public int compareTo(Movie m)
    {
        return this.year - m.year;
    }

    public Movie(String name , double rating, int year)
    {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    public double getRating(){return rating;}
    public String getName(){return name;}
    public int getYear(){return year;}
}
public class Main {

    public static void main(String[] args) {
        ArrayList<Movie> list = new ArrayList<>();
        list.add(new Movie("Avenger", 8.9, 2015));
        list.add(new Movie("Dark", 8.2, 2017));
        list.add(new Movie("Capton", 8.5, 1997));
        list.add(new Movie("Empire", 8.4, 1987));

        Collections.sort(list);

        System.out.println("movies after sorting ... ");
        for(Movie movie : list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }
    }
}
