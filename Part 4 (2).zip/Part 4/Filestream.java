import java.io.*;
public class Filestream {
    public static void main(String[] args) {
        
        try{
            byte fwrite[] = {11,21,3,40,5};
            OutputStream os = new FileOutputStream("test.txt");
            for(int i = 0;i<fwrite.length;i++)
            {
                //write the bytes
                os.write(fwrite[i]);
            }
            os.close();

            InputStream in = new FileInputStream("test.txt");
            int size = in.available();
            for(int i = 0;i<size;i++)
            {
               System.out.print(in.read()+" ");
            //    System.out.println((char)in.read());
            }
            in.close();
        }catch(IOException e)
        {
            System.out.println("its exception err");
        }
    }
}
