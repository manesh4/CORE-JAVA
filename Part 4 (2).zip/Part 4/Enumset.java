import java.util.*;
import java.util.EnumSet;


    enum Demo { code, is , java, lecture };
    public class Enumset {
    public static void main(String[] args) {
        EnumSet<Demo> set1;

        set1 = EnumSet.of(Demo.java,Demo.code,Demo.is,Demo.lecture);

        System.out.println("set 1 = "+set1);
    }
}
