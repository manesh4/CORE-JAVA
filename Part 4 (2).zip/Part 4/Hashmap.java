import java.util.*;
public class Hashmap {
    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();

        //insertion
        map.put("India", 120);
        map.put("USA", 130);
        map.put("China", 150);

        System.out.println(map);


        map.put("China", 180);
        System.out.println(map);

        //searching

        if(map.containsKey("China"))
        {
            System.out.println("key is present ");
        }
        else{
            System.out.println("key is not present");
        }

        System.out.println(map.get("China"));
        System.out.println(map.get("Singapore"));

        //iteration

        for(Map.Entry<String,Integer> i : map.entrySet()){
            System.out.println(i.getKey());
            System.out.println(i.getValue());
        }

        Set<String> keys = map.keySet();
        for(String key : keys){
            System.out.println(key+" "+map.get(key));
        }

        //remove
        map.remove("China");
        System.out.println(map);
    }
}
