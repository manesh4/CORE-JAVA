import java.util.LinkedHashMap;
import java.util.Map;

public class Linkedhashmap {
    public static void main(String[] args) {
        Map<String,Integer> map = new LinkedHashMap<>();
       
        map.put("India", 120);
        map.put("USA", 130);
        map.put("China", 150);

        // System.out.println(map);
        //iteration

        for(Map.Entry<String,Integer> i : map.entrySet()){
            System.out.print(i.getKey()+" : ");
            System.out.println(i.getValue());
        }

    }
}
