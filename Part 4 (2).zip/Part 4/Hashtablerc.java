// import java.util.*;
import java.util.Hashtable;
import java.util.Enumeration;
public class Hashtablerc {
    public static void main(String[] args) {
        Hashtable<String,Integer> hst = new Hashtable<>();

        //adding
        hst.put("A", 1);
        hst.put("B", 2);
        hst.put("C", 3);

        System.out.println(hst);

        Enumeration<String> keys  = hst.keys();
        while(keys.hasMoreElements())
        {
            String key = keys.nextElement();
            System.out.println("key: "+ key + ", Value: " + hst.get(key));
        }
     }
}
