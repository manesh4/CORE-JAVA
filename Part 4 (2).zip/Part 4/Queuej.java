import java.util.*;
public class Queuej {
    public static void main(String[] args) {
        Queue<String> queue = new LinkedList<>();

        //add
        queue.add("sprite");
        queue.add("coca_cola");
        queue.add("redbull");

        //print
        System.out.println("Queue = "+queue);
        
        String front = queue.remove();
        System.out.println("removed element = "+front);
        System.out.println("Queue = "+queue);
        queue.add("sting");
        String peek = queue.peek();
        System.out.println("peeked element = "+peek);
        System.out.println("Queue = "+queue);
    }
}
