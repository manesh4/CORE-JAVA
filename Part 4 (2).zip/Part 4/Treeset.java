import java.util.*;
public class Treeset {
    public static void main(String[] args) {
        Set<String> set = new TreeSet<>();

        set.add("India");
        set.add("America");
        set.add("Canada");

        System.out.println(set);
    }
}
