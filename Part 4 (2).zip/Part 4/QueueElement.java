import java.util.*;
public class QueueElement {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        //adding elements using for loop in q

        for(int i=0;i<5;i++)
        {
            queue.add(i);
        }
        System.out.println("Queue = "+queue);

        int front = queue.remove();
        System.out.println("removed element = "+front);
        System.out.println("Queue = "+queue);
        queue.add(8);
        int head = queue.peek();
        System.out.println("head element = "+head);
        System.out.println("Queue = "+queue);
        int size = queue.size();
        System.out.println("size = "+size);
    }
}
