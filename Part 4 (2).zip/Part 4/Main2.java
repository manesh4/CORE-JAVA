import java.io.*;
import java.util.*;

class Movie implements Comparable<Movie>
{
    private double rating;
    private String name;
    private int year;

    public int compareTo(Movie m)
    {
        return this.year - m.year;
    }

    public Movie(String name , double rating, int year)
    {
        this.name = name;
        this.rating = rating;
        this.year = year;
    }

    public double getRating(){return rating;}
    public String getName(){return name;}
    public int getYear(){return year;}
}

//class to compare movies by rating 

class Rating implements Comparator<Movie>
{
    public int compare(Movie m1, Movie m2)
    {
        if(m1.getRating()<m2.getRating())
        {
            return -1;
        }
        if(m1.getRating()>m2.getRating())
        {
            return 1;
        }
        else{
            return 0;
        }
    }
}
class Name implements Comparator<Movie>
{
    public int compare(Movie m1, Movie m2)
    {
        return m1.getName().compareTo(m2.getName());
    }
}
public class Main2 {
    
    public static void main(String[] args) {
        ArrayList<Movie> list = new ArrayList<>();
        list.add(new Movie("Avenger", 8.9, 2015));
        list.add(new Movie("Dark", 8.2, 2017));
        list.add(new Movie("Capton", 8.5, 1997));
        list.add(new Movie("Empire", 8.4, 1987));

        
        System.out.println("sorted by rating ... ");
        Rating rt = new Rating();
        Collections.sort(list,rt);
        for(Movie movie : list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }

        System.out.println("sorted by name ... ");
        Name nm = new Name();
        Collections.sort(list,nm);
        for(Movie movie : list)
        {
            System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
        }
    }
}
