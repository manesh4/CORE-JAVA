import javafx.geometry.Side;

public class Test2 {
    public static void main(String args[]) {
        int num1,num2;
        num1 = 10;
        num2 = 20;
        int num3 = num1+num2;

        System.out.println("additon of two no = "+num3);
        // System.out.println("addition = "+num1+num2);
        // System.out.println("addition = "+(num1+num2));

        //area of circle

        // double pi = 3.142;
        // double r = 4.2;
        // double area = pi*(r*r);
        // System.out.println("area of circle = "+area);

        //area of rectangle

        // int l,b;
        // l = 5;
        // b = 6;
        // System.out.println("area of rectangle = "+(l*b));

        //area of square

        // int side = 20;
        // System.out.println("area of square = "+(side*side));


        // Boolean b1,b2;
        // b1 = true;
        // b2 = false;

        // System.out.println(" b1&&b2 = "+(b1&&b2));
        // System.out.println(" b1||b2 = "+(b1||b2));
        // System.out.println(" !b1&&b2 = "+!(b1&&b2));

        //trunary operator

        // int num1,num2;
        // num1 = 100;
        // num2 = (num1<200)?500:600;
        // System.out.println("value of num2 = "+num2);
        // num2 = (num1<50)?500:600;
        // System.out.println("value of num2 = "+num2);
    }
}



