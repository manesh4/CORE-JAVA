public class Test
{
	public static void main(String args[])
	{
	System.out.print("Hello User, this is our first program in java...");
// 	System.out.println("this is the practical sessions");
// 	System.out.println("u gud to go now....");
// 	int a = 10;
// 	int b,c;
// 	b=20;
// 	c=30;
// 	System.out.println("value of a = "+a);
// System.out.println("value of b = "+b);
// System.out.println("value of c = "+c);
}
}