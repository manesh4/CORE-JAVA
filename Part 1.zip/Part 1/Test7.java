import java.util.*;
public class Test7 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        // System.out.println("enter no (1-3)");
        // int no = sc.nextInt();
        // switch(no)
        // {
        //     case 1:
        //         System.out.println("i m one");
        //         break;
        //     case 2:
        //         System.out.println("i m two");
        //         break;
        //     case 3:
        //         System.out.println("i m three");
        //         break;
        //     default:
        //         System.out.println("plz enter between(1-3)");
        // }

        // for(int i=1; i<=10;i++)
        // {
        //     if(i==4)
        //     {
        //         continue;
        //     }
        //     if(i==8)
        //     {
        //         break;
        //     }
        //     System.out.print(i+" ");
        // }

        // factorial program
        // System.out.println("enter no ");
        // int no = sc.nextInt();
        // int fact=1;
        // for(int i=1;i<=no;i++)
        // {
        //     fact = fact*i;
        // }
        // System.out.println("factorial = "+fact);

        // sum of the natural no
        // System.out.println("enter no ");
        // int no = sc.nextInt();
        // int sum = 0;
        //  for(int i=1;i<=no;i++)
        // {
        //     sum = sum+i;
        // }
        // System.out.println("sum of natural no  = "+sum);
    }
}
