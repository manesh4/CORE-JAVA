public class Test4 {
    public static void main(String args[]) {
        
        // //pre incre ++variable

        // int i,x;
        // i=10;
        // x = ++i;

        // System.out.println("value of x = "+x);
        // System.out.println("value of i = "+i);


        //post incre variable++

        // int i,x;
        // i=10;
        // x = i++;

        // System.out.println("value of x = "+x);
        // System.out.println("value of i = "+i);

        //pre decre  --variable

        // int i,x;
        // i=10;
        // x = --i;

        // System.out.println("value of x = "+x);
        // System.out.println("value of i = "+i);



        //post  decre variable--

        // int i,x;
        // i=10;
        // x = i--;

        // System.out.println("value of x = "+x);
        // System.out.println("value of i = "+i);


        // int x,a,b,c;
        // a=2;
        // b=4;
        // c=5;

        // x = a-- + b++ - ++c;
        // System.out.println("value of x = "+x);
    }
}
