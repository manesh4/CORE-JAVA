import java.util.*;
public class Test8 {

    //this is defination of static method
    // static void show()
    // {
    //     System.out.println("hi i m static method");
    // }

    // public void display()
    // {
    //     System.out.println("hi i m public method call me with object");
    // }

    // int no;
    // public int get(int x)
    // {
    //     no = x*x;
    //     return no;
    // }
    // public void printAddition(int a,int b)
    // {
    //     int result = a+b;
    //     System.out.println("additon  = "+result);
    // }
    public static void main(String args[]) {
        //call to static method
    //     show();
    // Test8 t = new Test8();
    // t.display();

    // int result = t.get(5);
    // System.out.println("square = "+ result);


    // Scanner sc = new Scanner(System.in);
    //  int a,b;
    // System.out.println("enter two no's");
    // a = sc.nextInt();
    // b = sc.nextInt();
    // Test8 t = new Test8();
    // t.printAddition(a,b);

    }

}
