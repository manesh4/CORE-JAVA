public class Test9 {
    public static void main(String args[])
    {
        //1.count the no of digit
        // int n = 1234;
        // int n = 35248;
        // int count=0;
        // while(n>0)
        // {
        //     n = n/10;  
        //     count++;   
        // }
        // System.out.println("no of digit is = "+count);


        //2.calculate sum of digits of given no
        // int n = 12345;
        // int sum=0,rem;
        // while(n>0)
        // {
        //     rem = n % 10; 
        //     sum = sum + rem; 
        //     n = n/10;
        // }
        // System.out.println("sum of digits is = "+sum);


        // int year = 2024;

        // if((year%4==0) &&((year%400==0)||(year%100!=0)))
        // {
        //     System.out.println("it is leap year");
        // }
        // else{
        //     System.out.println("Not Leap Yer");
        // }


        // //star pattern 1

        // for(int i=1;i<=4;i++)
        // {
        //     for(int j=1;j<=i;j++)
        //     {
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        // //star pattern 2

        // for(int i=1;i<=4;i++)
        // {
        //     for(int j=4;j>=i;j--)
        //     {
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        // //star pattern 3

        // for(int i=1;i<=4;i++)
        // {
        //     for(int j=1;j<=i;j++)
        //     {
        //         System.out.print(j+" ");
        //     }
        //     System.out.println();
        // }


        //star pattern 4

        // for(int i=1;i<=4;i++)
        // {
        //     for(int j=1;j<=i;j++)
        //     {
        //         System.out.print(i+" ");
        //     }
        //     System.out.println();
        // }

}
}
