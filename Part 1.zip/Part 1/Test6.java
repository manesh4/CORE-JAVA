import java.util.*;
public class Test6 {
    public static void main(String args[]) {
       
        Scanner sc = new Scanner(System.in);
        System.out.println("enter no");
        int no = sc.nextInt();

        // int no = 1;

        while(no<=10)
        {
            System.out.print(no+",");
            no++;
        }


        
        // int no = 10;

        // while(no>=1)
        // {
        //     System.out.print(no+",");
        //     no--;
        // }


        //  int no = 1;

        //  do{
        //     System.out.print(no+" ");
        //     no++;
        //  }while(no<=10);

        // int no = 1;

        // do{
        //    System.out.print(no+" ");
        //    no++;
        // }while(no<0);

        // int no = 2;

        // do{
        //    System.out.print(no+" ");
        //    no=no+2;
        // }while(no<=100);

        // int no = 1;

        // do{
        //    System.out.print(no+" ");
        //    no=no+2;
        // }while(no<=100);




        // for(int i=1;i<=10;i++)
        // {
        //     System.out.print(i+" ");
        // }

        // for(int i=10;i>=1;i--)
        // {
        //     System.out.print(i+" ");
        // }

    }
}
