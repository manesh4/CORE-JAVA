import java.util.*;
// import java.util.Scanner;
public class Test3 {
    public static void main(String args[]) {
       
        Scanner sc  = new Scanner(System.in);

        // System.out.println("enter integer no");
        
        // int number  = sc.nextInt();

        // System.out.println("enter float no");

        // double d = sc.nextDouble();

        // System.out.println("enter alphabet");

        // char ch = sc.next().charAt(0);

        // System.out.println("enter your name");

        // String str = sc.next();
        // // String str2 = sc.nextLine();

        // System.out.println("integer no = "+number);
        // System.out.println("float no = "+d);
        // System.out.println("entered alphabet = "+ch);
        // System.out.println("your name = "+str);


        int num1,num2,total;

        // System.out.println("enter 1st no");
        // num1 = sc.nextInt();
        // System.out.println("enter 2nd no");
        // num2 = sc.nextInt();
        // total = num1+num2;
        // System.out.println("addition = "+total);

        //area of circle

        // System.out.println("enter radius");
        // double r = sc.nextDouble();
        // double pi = 3.142;
        // double area = pi*(r*r);
        // System.out.println("area of circle = "+area);

         //area of rectangle

      //area of rectangle

    //   System.out.println("enter length and breadth");
    //     int l,b;
    //     l = sc.nextInt();
    //     b = sc.nextInt();
    //     System.out.println("area of rectangle = "+(l*b));

  

    }
}
