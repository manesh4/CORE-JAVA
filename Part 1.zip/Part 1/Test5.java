import java.util.*;
public class Test5 {
    public static void main(String args[]) {
        
     Scanner sc = new Scanner(System.in);


     //simple if

 
        // System.out.println("enter any number");
        // int no = sc.nextInt();
        // if(no<100)
        // {
        //     System.out.println("your no is less than 100");
        // }



        //if else

        // System.out.println("enter your age");
        // int age = sc.nextInt();

        // if(age<18)
        // {
        //     System.out.println("u can't vote");
        // }
        // else{
        //     System.out.println("u can vote");
        // }


        //else if ladder

        // System.out.println("enter any no");
        // int no = sc.nextInt();

        // if(no<0)
        // {
        //     System.out.println("negative no");
        // }
        // else if(no>0){
        //     System.out.println("positive no");
        // }
        // else{
        //     System.out.println("no is zero");
        // }

        // System.out.println("enter any no");
        // int no = sc.nextInt();

        // if(no==1)
        // {
        //     System.out.println("Hello");
        // }
        // else if(no==2){
        //     System.out.println("Hey Guys");
        // }
        // else if(no==3){
        //     System.out.println("good day");
        // }
        // else if(no==4)
        // {
        //     System.out.println("Bad day");
        // }
        // else{
        //     System.out.println("plz enter no betweens (1-4)");
        // }

        // System.out.println("enter weekday no(1-7)");
        // int no = sc.nextInt();

        // if(no==1)
        // {
        //     System.out.println("Monday");
        // }
        // else if(no==2){
        //     System.out.println("Tuesday");
        // }
        // else if(no==3){
        //     System.out.println("Wednsday");
        // }
        // else if(no==4)
        // {
        //     System.out.println("Thursday");
        // }
        // else if(no==5){
        //     System.out.println("Friday");
        // }
        // else if(no==6)
        // {
        //     System.out.println("Saturday");
        // }
        // else if(no==7)
        // {
        //     System.out.println("Sunday");
        // }
        // else{
        //     System.out.println("plz enter correct values");
        // }



        // System.out.println("enter 1st no");
        // int num1 = sc.nextInt();
        // System.out.println("enter 2nd no");
        // int num2 = sc.nextInt();
        // System.out.println("enter 3rd no");
        // int num3 = sc.nextInt();

        // if(num1>num2)
        // {
        //     if(num1>num3)
        //     {
        //         System.out.println("num1 is greater");
        //     }
        //     else{
        //         System.out.println("num3 is greater");
        //     }
        // }
        // else{
        //     if(num2>num3)
        //     {
        //         System.out.println("num2 is greater");
        //     }
        //     else{
        //         System.out.println("num3 is greater");
        //     }
        // }

    }
}
