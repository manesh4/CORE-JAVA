public class Sample {
    private void getvalue()
    {
        int total=50;
        class Inner{
            public int div;
            public int rem;

            public Inner()
            {
                div=5;
                rem=total%div;
            }
            private int getDive()
            {
                return div;
            }
            private int getRem()
            {
                return rem;
            }
            private int getQue()
            {
                return total/div;
            }
        }
            Inner inner = new Inner();
            System.out.println("div ="+inner.getDive());
            System.out.println("rem ="+inner.getRem());
            System.out.println("quo ="+inner.getQue());
    }
        public static void main(String[] args) {
            Sample s = new Sample();
            s.getvalue();
        }
}
    

