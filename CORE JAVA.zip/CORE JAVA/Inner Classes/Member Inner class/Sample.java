public class Sample {
    private int a=10;
    class Inner{
        void show()
        {
            System.out.println("Value of a ="+a);
        }
    }
    public static void main(String[] args) {
        Sample s = new Sample();
        Sample.Inner in = s.new Inner();
        in.show(); 
    }
    
}
