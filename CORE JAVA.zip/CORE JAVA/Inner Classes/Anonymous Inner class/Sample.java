interface Demo{
    int x=20;
    void getdata();
}
class MyClass implements Demo {
    public void getdata()
    {
        System.out.println("Value of x= "+x);
    }
}
public class Sample {
    public static void main(String[] args) {
        MyClass obj = new MyClass();
        obj.getdata();
    }

    
}
