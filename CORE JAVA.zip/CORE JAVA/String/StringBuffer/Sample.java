public class Sample {
    public static void main(String[] args) {
        
        StringBuffer sb = new StringBuffer("Hello");
        System.out.println(sb);
        
        sb.insert(0,"java");
        System.out.println(sb);

        sb.replace(1,3,"pro");
        System.out.println(sb);

        sb.delete(1,2);
        System.out.println(sb);

        sb.reverse();
        System.out.println(sb);


        StringBuffer sb = new StringBuffer();
        System.out.println(sb.capacity());

        sb.append("Hello");
        System.out.println(sb.capacity());

        sb.append("java is my favrt language");
        System.out.println(sb.capacity());
    }
    
}
