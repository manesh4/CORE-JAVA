public class Sample {
    public static void main(String[] args) {
        
        String str2="Perm";
        str2="Mahajan";
        System.out.println(str2);


        StringBuilder sb = new StringBuilder("Prem");
        System.out.println(sb);

        System.out.println(sb.charAt(0));

        sb.setCharAt(0,'n');
        System.out.println(sb);

        sb.insert(0,'p');
        System.out.println(sb);

        sb.delete(1,2);
        System.out.println(sb);

        sb.append(" ");
        sb.append("Mahajan");
        System.out.println(sb);
    }
    
}
