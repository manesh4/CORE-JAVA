public class Sample {
    public static void main(String[] args) {
        
        //using char Array
       // char ch[]={'j','a','v','a'};
        //System.out.println(ch);

        //bu using String class
       // String s = new String(ch);
       // System.out.println(s);

        //String s = new String("Java Programming");
        //System.out.println(s);

        //by using literals
        //String str = "Java Programming";
        //System.out.println(str);

        String str = "this is a core java programming";
        System.out.println(str);

        //System.out.println(str.charAt(0));

        //System.out.println("String of Length ="+str.length());

        String name1="Prem";
        String name2="prem";
        //String str2=String.format("name is = %s",name1);
        //System.out.println(str2);

        //System.out.println(name1.equals(name2));

        //System.out.println(str.substring(2,10));
        //System.out.println(str.substring(2));

        System.out.println(name1.toLowerCase());
        System.out.println(name2.toUpperCase());
    



        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());

        System.out.println(str.trim());
        System.out.println(str.indexOf("is"));
        System.out.println(str.isEmpty());

        String str1=" ";
        System.out.println(str1.isEmpty());
    }
    
}
