

//public class Test {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub



/* 
//public class Test{
//	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}

*/

/*  

*
**
***
**** 

*/
/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=4; j>=i; j--)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}       

*/

/*
 
****
***
**
*

*/


/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
}       

*/


/*
 
1
12
123
1234

 */

/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(i);
			}
			System.out.println();
		}
	}
}       

*/


/*
1
22
333
4444

 */

/* 
 public class Test{
	public static void main(String[] args) {
		int n=1;
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(n);
				n++;
			}
			System.out.println();
		}
	}
}       

*/


/*

1
23
456
78910

 */
/* 
 public class Test{
	public static void main(String[] args) {
		
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=4; j++)
			if((i>=2&&j>=2) && (i<=3&&j<=3))
			{
				System.out.print(" ");
			}
			else{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}

o/p:
****
*  *
*  *
****

*/

public class Test{
	public static void main(String[] args) {
		
		for(int i=1; i<=5; i++)
		{
			for(int j=1; j<=5; j++)
			if(i==j ||i+j==6)
			{
				System.out.print("*");
			}
			else{
				System.out.print(" ");
			}
			System.out.println();
		}
	}
}

o/p:

*   *
 * *
  *
 * *
*   *