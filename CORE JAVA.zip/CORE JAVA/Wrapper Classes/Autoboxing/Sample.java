public class Sample {
    public static void main(String[] args) {
        
        //convert int into Integer
        int a=5;

        //Converting explicitly
        Integer i =Integer.valueOf(a);

        //autoboxing
        Integer j=a;
        System.out.println(a+" "+i+" "+j);

    }
    
}
