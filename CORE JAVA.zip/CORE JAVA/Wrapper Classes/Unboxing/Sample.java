public class Sample {
    public static void main(String[] args) {
        
        //unboxing
        Integer a = new Integer(10);

        //Explicitly
        int i = a.intValue();

        //autoboxing
        int j=a;
        System.out.println(a+" "+i+" "+j);

    }
    
}
