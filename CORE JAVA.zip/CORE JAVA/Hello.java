public class Hello {
    public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=5;i>=1;i--) {
			for(int j=1;j<=i;j++){
				System.out.print(j+1);
			}
			System.out.println();
		}

	}

}


package Mypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Employee {
	
	public void createConnection()
	{
		try {
			String url = "jdbc:mysql://localhost:3306";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			System.out.println("Connection Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public void createDatabase()
	{
			try {
				String url = "jdbc:mysql://localhost:3306";
				String userName = "root";
				String passWord = "Manesh@123";
				
				Connection con =DriverManager.getConnection(url,userName,passWord);
				
				//create Statement 
				Statement stm = con.createStatement();
				
				//Execute query
				String query ="create database stud";
				stm.execute(query);
				
				System.out.println("Database created Successfully...........!");
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
	}
	
	public void createTable()
	{ 
		try {
			String url = "jdbc:mysql://localhost:3306/stud";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="create table emp(empid int(3),empname varchar(255),empemail varchar(255))";
			stm.execute(query);
			
			System.out.println("Table created Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public void createData() 
	{
		try {
			String url = "jdbc:mysql://localhost:3306/stud";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="insert into emp(empid,empname,empmail)values(1,'manesh','manesh@123')";
			stm.execute(query);
			
			System.out.println("Data inseted Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
	

package Mypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args)  {
		
	Employee e = new Employee();
	
//	e.createConnection();
	
//	e.createDatabase();
	
//	e.createTable();
	
	e.createData();
	
	}
}




