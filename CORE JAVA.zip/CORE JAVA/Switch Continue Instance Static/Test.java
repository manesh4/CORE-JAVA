package Switcj;

//public class Test {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub

	





 
import java.util.*;
//import java.util Scanner;
public class Test{
	public static void main(String[] args){
	
		Scanner Sc = new Scanner(System.in);
		
		System.out.println("Enter the Weekly no day (1-7)");
		int no = Sc.nextInt();
		

		// switch case
		switch(no)
		{
			case 1:
				System.out.println("working day ...... Monday");
				break;
				
			case 2:
				System.out.println("working day ...... Tuesday");
				break;
				
			case 3:
				System.out.println("working day ...... wendesday");
				break;
				
			case 4:
				System.out.println("working day ...... Thursday");
				break;
				
			case 5:
				System.out.println("working day ...... Firday");
				break;
				
			case 6:
				System.out.println("Holiday day ...... Saturday");
				break;
				
			case 7:
				System.out.println("working day ...... Sanday");
				break;
				
			default:
				System.out.println("Plz enter the correct value");
		}
	}
}

			
		
		
		
		
	//	System.out.println("Enter the Number (1-3)");
	//	int n = Sc.nextInt();

/*
		switch(n)
		{
		case 1:
			System.out.println(" I m one");
			break;
			
		case 2:
			System.out.println(" I m two");
			break;
			
		case 3:
			System.out.println(" I m three");
			break;
			
		default:
			System.out.println(" Plz correct number");
		}
	}
}

*/			
		
/*	
		// continue statement
		for(int i=1;i<=10; i++)
				{
					if(i==4)
					{
						continue;
					}
					if(i==8)
					{
						break;
					}
					System.out.println(i+" ");
				}
	}
}
				
*/
			  
/*		
  //   Factorial number
		System.out.println("Enter the number");
		int n = Sc.nextInt();
		
		int fact =1;
		
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println("factorial "+fact);
				
	}
*/

		
/*		
		 //   Natural number
		System.out.println("Enter the number");
		int n = Sc.nextInt();
		
		int sum =0;
		
		for(int i=1;i<=n;i++)
		{
			sum=sum+i;
		}
		System.out.println(sum);
				
	}
}

*/   


		
/*
 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public void show()
	{
		System.out.println("Hello Function");
	}
	public static void main(String [] args) {
		Test t = new Test();
		t.show();
	}
}

*/

/*

import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public void show(String s)
	{
		System.out.println("Hello Function"+s);
	}
	public static void main(String [] args) {
		Test t = new Test();
		t.show("Java");
	}
}

*/


/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public int show()
	{
		return 10;
	}
	public static void main(String [] args) {
		Test t = new Test();
		System.out.println(t.show());
		
		//int res =t.show();
		//System.out.println(res);
		
	}
}
*/





/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public int show(int a, int b)
	{
		return a+b;
	}
	public static void main(String [] args) {
		Test t = new Test();
		System.out.println(t.show());
		
		//int res =Test.show(10,20);
		//System.out.println(res);
		
	}
}
*/



/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//static methods
	public static void  display()
	{
		System.out.println("Hello function");
	}
	public static void main(String [] args) {
		Test h = new Test();
		//display();
		
		//with class
		Test.display();
		
		
	}
}
*/


/* 
 //count the number of digit
 public class Test{
	public static void main(String[] args) {
		int n =12345;
		int count =0;
		while (n>0)
		{
			n=n/10;
			count ++;
		}
		System.out.println("no of digit = " +count);
	}
 }
*/
//

/* 
//ccalculate sum of digits of given number
 public class Test{
	public static void main(String[] args) {
		
		int n =1234;
		int sum=0,rem;
		while (n>0)
		{
			rem =n%10;
			sum = sum + rem;
			n=n/10;
		}
		System.out.println(" sum of digit = " +sum);
	}
 }
*/



/* 
int year=2024;
 if((year%4==0)&&(year%400==0)||(year%100==0))
 {
	System.out.println("Is leap Year");
 }
 else{
	System.out.println("NOT leap Year");
 }
}  
 }

*/