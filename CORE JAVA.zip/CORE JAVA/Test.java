//public class Test {
   // public static void main(String[] args) {

 /*       
        System.out.println("This is my program");
    }
}
*/

/*  
        int a;
        a=10;
        int b=20;
        int c,d;
        c=30;
        d=40;
        System.out.println("The value of"+a);
        System.out.println("The value of"+(a+b));
        System.out.println("The value of"+b);
        int sub =d-c;
        System.out.println("The subtraction of d and c"+sub);

    }
    
}
*/

/* 
    double pi,area,r;
    pi=3.142;
    r=6.2;
    area=pi*(r*r);
    System.out.println("area ="+area);
}
}
*/

/* 
    int l,b,area;
    l=5;
    b=10;
    area=l*b;
    System.out.println("area ="+area);
}
}

*/

/* 
    int side,area;
    side=5;
    area=side*side;
    System.out.println("area ="+area);
}
}

*/

/* 
    boolean b1,b2;
    b1=true;
    b2=false;
    System.out.println("b1&&b2"+(b1&&b2));
    System.out.println("b1||b2"+(b1||b2));
    System.out.println("!(b1&&b2)"+!(b1&&b2));
    }
}

*/

/* 
int num1,num2;
num1=10;
num2=(num1>5)?100:200;
System.out.println("num2="+num2);
    }
}

*/


//import java.util.*;
//import java.util.Scanner;
//public class Test{
   // public static void main(String[] args) {
      //  Scanner sc =new Scanner(System.in);
/* 
        System.out.println("Enter the number:");
        int n = sc.nextInt();
        System.out.println("value ="+n);
    }
}

*/

/* 

System.out.println("Enter float number:");
double f = sc.nextDouble();
System.out.println("value ="+f);
}
}

*/

/* 
System.out.println("Enter the char:");
char c = sc.next().charAt(0);
System.out.println("value ="+c);
}
}

*/

/* 
System.out.println("Enter the String:");
String str = sc.next();
System.out.println("value ="+str);
}
}

*/

/* 
System.out.println("Enter the String:");
String str = sc.nextLine();
System.out.println("value ="+str);
}
}

*/

/*
import java.util.*;
    public class Test{
        public static void main(String[] args) {
            Scanner sc =new Scanner(System.in);
            int num1,num2,total;
            System.out.println("Enter the no:");
            num1  = sc.nextInt();
            System.out.println("Enter the no:");
            num2  = sc.nextInt();
            total = num1+num2;
            System.out.println("The addition of ="+total);

        }
    }
    
*/


//import java.util.*;
  //  public class Test{
    //    public static void main(String[] args) {
        	
/*
        	//Pre incre
        	int i,x;
        	i=10;
        	x=++i;
        	System.out.println("x="+x);
        	System.out.println("i="+i);
        }
    }
        	
 */
        	
 /*    	
        	
          	//post incre
        	int i,x;
        	i=10;
        	x=i++;
        	System.out.println("x="+x);
        	System.out.println("i="+i);
        }
    }
        	
*/
        	
/*   	
        	//Pre Decre
        	int i,x;
        	i=10;
        	x=--i;
        	System.out.println("x="+x);
        	System.out.println("i="+i);
        }
    }
 */
        	
 /*	
        	//Pre Decre
        	int i,x;
        	i=10;
        	x=i--;
        	System.out.println("x="+x);
        	System.out.println("i="+i);
        }
    }
 */
        	
 /*
            //e.g
        	int x,a,b,c;
        	a=2;
        	b=4;
        	c=5;
        	x=a-- + b++ - ++c;
        	System.out.println("x="+x);
        }
    }
 */
   
/*
        	// if
        	int n=10;
        	if(n<20)
        	{
        		System.out.println("Is less than number");
        	}
        }
     }
*/
        	
/*
        	
        	// if
        	int n=10;
        	if(n>20)
        	{
        		System.out.println("Is less than number");
        	}
        }
     }
 */
        	
/*
        	
        	//if else
        	int n=10;
        	if(n>20)
        	{
        		System.out.println("Greater");
        	}
        	else 
        	{
        		System.out.println("Smaller");
        	}
        }
      }
 */

/*        	
        	//else if ladder
        	int n=10;
        	if(n>0);
        	{
        		System.out.println("+tv");
        	}
        	else if(n<0)
        	{
        		System.out.println("-tv");
        	}
        	else {
        		System.out.println("Zero");
        	}
        }
    }
*/
        	
/*
        	
        	
        	//else if ladder
        	int n=2;
        	if(n==1);
        	{
        		System.out.println("Hi");
        	}
        	else if(n==2)
        	{
        		System.out.println("Hello");
        	}
        	else if(n==3)
        	{
        		System.out.println("Bye");
        	}
        	else {
        		System.out.println("plz enter no.s (1-3)");
        	}
        }
    }
 */
        	
/*       	
import java.util.*;
public class Test{
	public static void main(String[] args){
	Scanner Sc = new Scanner(System.in);
		

		// greate three 
		System.out.println("Enter Three number");
		int a=Sc.nextInt();
		int b=Sc.nextInt();
		int c=Sc.nextInt();
		
	if(a>b)
	{
		if(a<c)
	{
		System.out.println("a is greater");
		}
	else
	{
		System.out.println("c is greater");
	}
}
else
{
	if(b>c)
	{
		System.out.println("b is greater");
		}
	else
	{
		System.out.println("c is greater");
	}
}
}
}

*/
	
/*
		//if else
		System.out.println("Enter the age");
		int age=Sc.nextInt();
		
		if(age<18)
		{
			System.out.println("u can't vote");
		}
		else
		{
			System.out.println("u can vote");
		}
	}
}
*/
		
/*		
 		//else if ladder
		System.out.println("Enter weekday no(1-7)");
		int n=Sc.nextInt();
		
		if(n==1)
		{
			System.out.println("Monday");
		}
		else if(n==2)
		{
			System.out.println("Tuesday");
		}
		else if(n==3)
		{
			System.out.println("Wednsday");
		}
		else if(n==4)
		{
			System.out.println("Thurday");
		}
		else if(n==5)
		{
			System.out.println("Friday");
		}
		else if(n==6)
		{
			System.out.println("Saturday");
		}
		else if(n==7)
		{
			System.out.println("Sanday");
		}
		else 
		{
			System.out.println("Plz enter correct value");
		}
	}
}
*/
		
/*
		
	     ///while loop
		int i=1;
		while(i<=10)
		{
			System.out.println(i+" ");
			i++;
		}
	}
}
*/
		
/*
		
		
		
		 //while loop
		int i=1;
		while(i>=10)
		{
			System.out.println(i+" ");
			i--;
		}
	}
}
		
*/
		
/*
		
		
		 // do while loop
		int i=1;
		do
		{
			System.out.println(" "+i);
			i++;
		}while(i<=10);
		
	}
}

*/
		
/*
		
		
		 // do while loop
		int i=12;
		do
		{
			System.out.println(" "+i);
			i++;
		}while(i<=10);
		
	}
}

*/
		
		
/*
		
		//for loops
		for(int i=1;i<=5;i++)
		{
			System.out.println(i+" ");
		}
	}
}
*/	
		  
		
/*		
		System.out.println("Enter the No ");
		int n  = Sc.nextInt();
		if(n%2==0)
		{
			System.out.println("Even");
		}
		else
		{
			System.out.println("Odd");
		}
	}
}

*/
		
/*
		// 1 to 100 Even no.s Print
		int n=2;
		do
		{
			System.out.println(n+" ");
			n+=2;
		}while(n<=100);
			
	}
}	
*/ 
		
/*	
		// 1 to 100 Odd no.s Print
				int n=1;
				do
				{
					System.out.println(n+" ");
					n+=2;
				}while(n<=100);
					
			}
		}	


*/

/* 
import java.util.*;
//import java.util Scanner;
public class Test{
	public static void main(String[] args){
	
		Scanner Sc = new Scanner(System.in);
		
		System.out.println("Enter the Weekly no day (1-7)");
		int no = Sc.nextInt();
		

		// switch case
		switch(no)
		{
			case 1:
				System.out.println("working day ...... Monday");
				break;
				
			case 2:
				System.out.println("working day ...... Tuesday");
				break;
				
			case 3:
				System.out.println("working day ...... wendesday");
				break;
				
			case 4:
				System.out.println("working day ...... Thursday");
				break;
				
			case 5:
				System.out.println("working day ...... Firday");
				break;
				
			case 6:
				System.out.println("Holiday day ...... Saturday");
				break;
				
			case 7:
				System.out.println("working day ...... Sanday");
				break;
				
			default:
				System.out.println("Plz enter the correct value");
		}
	}
}
*/
			
		
		
		
		
	//	System.out.println("Enter the Number (1-3)");
	//	int n = Sc.nextInt();

/*
		switch(n)
		{
		case 1:
			System.out.println(" I m one");
			break;
			
		case 2:
			System.out.println(" I m two");
			break;
			
		case 3:
			System.out.println(" I m three");
			break;
			
		default:
			System.out.println(" Plz correct number");
		}
	}
}

*/			
		
/*	
		// continue statement
		for(int i=1;i<=10; i++)
				{
					if(i==4)
					{
						continue;
					}
					if(i==8)
					{
						break;
					}
					System.out.println(i+" ");
				}
	}
}
				
*/
			  
/*		
  //   Factorial number
		System.out.println("Enter the number");
		int n = Sc.nextInt();
		
		int fact =1;
		
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println("factorial "+fact);
				
	}
*/

		
/*		
		 //   Natural number
		System.out.println("Enter the number");
		int n = Sc.nextInt();
		
		int sum =0;
		
		for(int i=1;i<=n;i++)
		{
			sum=sum+i;
		}
		System.out.println(sum);
				
	}
}

*/   


		
/*
 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public void show()
	{
		System.out.println("Hello Function");
	}
	public static void main(String [] args) {
		Test t = new Test();
		t.show();
	}
}

*/

/*

import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public void show(String s)
	{
		System.out.println("Hello Function"+s);
	}
	public static void main(String [] args) {
		Test t = new Test();
		t.show("Java");
	}
}

*/


/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public int show()
	{
		return 10;
	}
	public static void main(String [] args) {
		Test t = new Test();
		System.out.println(t.show());
		
		//int res =t.show();
		//System.out.println(res);
		
	}
}
*/





/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//Instance methods
	public int show(int a, int b)
	{
		return a+b;
	}
	public static void main(String [] args) {
		Test t = new Test();
		System.out.println(t.show());
		
		//int res =Test.show(10,20);
		//System.out.println(res);
		
	}
}
*/



/* 
import java.util.*;
//import java.util.Scanner;
public class Test{
	//static methods
	public static void  display()
	{
		System.out.println("Hello function");
	}
	public static void main(String [] args) {
		Test h = new Test();
		//display();
		
		//with class
		Test.display();
		
		
	}
}
*/


/* 
 //count the number of digit
 public class Test{
	public static void main(String[] args) {
		int n =12345;
		int count =0;
		while (n>0)
		{
			n=n/10;
			count ++;
		}
		System.out.println("no of digit = " +count);
	}
 }
*/
//

/* 
//ccalculate sum of digits of given number
 public class Test{
	public static void main(String[] args) {
		
		int n =1234;
		int sum=0,rem;
		while (n>0)
		{
			rem =n%10;
			sum = sum + rem;
			n=n/10;
		}
		System.out.println(" sum of digit = " +sum);
	}
 }
*/



/* 
int year=2024;
 if((year%4==0)&&(year%400==0)||(year%100==0))
 {
	System.out.println("Is leap Year");
 }
 else{
	System.out.println("NOT leap Year");
 }
}  
 }

*/
/* 

public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}

*/

/*  

*
**
***
**** 

*/
/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=4; j>=i; j--)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}       

*/

/*
 
****
***
**
*

*/


/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(j);
			}
			System.out.println();
		}
	}
}       

*/


/*
 
1
12
123
1234

 */

/* 
public class Test{
	public static void main(String[] args) {
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(i);
			}
			System.out.println();
		}
	}
}       

*/


/*
1
22
333
4444

 */

/* 
 public class Test{
	public static void main(String[] args) {
		int n=1;
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j++)
			{
				System.out.print(n);
				n++;
			}
			System.out.println();
		}
	}
}       

*/


/*

1
23
456
78910

 */

 public class Test{
	public static void main(String[] args) {
		int n=10;
		for(int i=1; i<=4; i++)
		{
			for(int j=1; j<=i; j--)
			{
				System.out.print(n);
				n--;
			}
			System.out.println();
		}
	}
}       