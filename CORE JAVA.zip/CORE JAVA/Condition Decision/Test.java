





//import java.util.*;
//  public class Test{
  //    public static void main(String[] args) {
      	
/*
      	//Pre incre
      	int i,x;
      	i=10;
      	x=++i;
      	System.out.println("x="+x);
      	System.out.println("i="+i);
      }
  }
      	
*/
      	
/*    	
      	
        	//post incre
      	int i,x;
      	i=10;
      	x=i++;
      	System.out.println("x="+x);
      	System.out.println("i="+i);
      }
  }
      	
*/
      	
/*   	
      	//Pre Decre
      	int i,x;
      	i=10;
      	x=--i;
      	System.out.println("x="+x);
      	System.out.println("i="+i);
      }
  }
*/
      	
/*	
      	//Pre Decre
      	int i,x;
      	i=10;
      	x=i--;
      	System.out.println("x="+x);
      	System.out.println("i="+i);
      }
  }
*/
      	
/*
          //e.g
      	int x,a,b,c;
      	a=2;
      	b=4;
      	c=5;
      	x=a-- + b++ - ++c;
      	System.out.println("x="+x);
      }
  }
*/
 
/*
      	// if
      	int n=10;
      	if(n<20)
      	{
      		System.out.println("Is less than number");
      	}
      }
   }
*/
      	
/*
      	
      	// if
      	int n=10;
      	if(n>20)
      	{
      		System.out.println("Is less than number");
      	}
      }
   }
*/
      	
/*
      	
      	//if else
      	int n=10;
      	if(n>20)
      	{
      		System.out.println("Greater");
      	}
      	else 
      	{
      		System.out.println("Smaller");
      	}
      }
    }
*/

/*        	
      	//else if ladder
      	int n=10;
      	if(n>0);
      	{
      		System.out.println("+tv");
      	}
      	else if(n<0)
      	{
      		System.out.println("-tv");
      	}
      	else {
      		System.out.println("Zero");
      	}
      }
  }
*/
      	
/*
      	
      	
      	//else if ladder
      	int n=2;
      	if(n==1);
      	{
      		System.out.println("Hi");
      	}
      	else if(n==2)
      	{
      		System.out.println("Hello");
      	}
      	else if(n==3)
      	{
      		System.out.println("Bye");
      	}
      	else {
      		System.out.println("plz enter no.s (1-3)");
      	}
      }
  }
*/
      	
      	
import java.util.*;
public class Test{
	public static void main(String[] args){
	Scanner Sc = new Scanner(System.in);
		

		// greate three 
		System.out.println("Enter Three number");
		int a=Sc.nextInt();
		int b=Sc.nextInt();
		int c=Sc.nextInt();
		
	if(a>b)
	{
		if(a<c)
	{
		System.out.println("a is greater");
		}
	else
	{
		System.out.println("c is greater");
	}
}
else
{
	if(b>c)
	{
		System.out.println("b is greater");
		}
	else
	{
		System.out.println("c is greater");
	}
}
}
}


	
/*
		//if else
		System.out.println("Enter the age");
		int age=Sc.nextInt();
		
		if(age<18)
		{
			System.out.println("u can't vote");
		}
		else
		{
			System.out.println("u can vote");
		}
	}
}
*/
		
/*		
		//else if ladder
		System.out.println("Enter weekday no(1-7)");
		int n=Sc.nextInt();
		
		if(n==1)
		{
			System.out.println("Monday");
		}
		else if(n==2)
		{
			System.out.println("Tuesday");
		}
		else if(n==3)
		{
			System.out.println("Wednsday");
		}
		else if(n==4)
		{
			System.out.println("Thurday");
		}
		else if(n==5)
		{
			System.out.println("Friday");
		}
		else if(n==6)
		{
			System.out.println("Saturday");
		}
		else if(n==7)
		{
			System.out.println("Sanday");
		}
		else 
		{
			System.out.println("Plz enter correct value");
		}
	}
}
*/