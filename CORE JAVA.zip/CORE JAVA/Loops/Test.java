import java.util.*;
public class Test {
	public static void main(String[] args) {
		

		

		
	     ///while loop
		int i=1;
		while(i<=10)
		{
			System.out.println(i+" ");
			i++;
		}
	}
}

		
/*
		
		
		
		 //while loop
		int i=1;
		while(i>=10)
		{
			System.out.println(i+" ");
			i--;
		}
	}
}
		
*/
		
/*
		
		
		 // do while loop
		int i=1;
		do
		{
			System.out.println(" "+i);
			i++;
		}while(i<=10);
		
	}
}

*/
		
/*
		
		
		 // do while loop
		int i=12;
		do
		{
			System.out.println(" "+i);
			i++;
		}while(i<=10);
		
	}
}

*/
		
		
/*
		
		//for loops
		for(int i=1;i<=5;i++)
		{
			System.out.println(i+" ");
		}
	}
}
*/	
		  
		
/*		
		System.out.println("Enter the No ");
		int n  = Sc.nextInt();
		if(n%2==0)
		{
			System.out.println("Even");
		}
		else
		{
			System.out.println("Odd");
		}
	}
}

*/
		
/*
		// 1 to 100 Even no.s Print
		int n=2;
		do
		{
			System.out.println(n+" ");
			n+=2;
		}while(n<=100);
			
	}
}	
*/ 
		
/*	
		// 1 to 100 Odd no.s Print
				int n=1;
				do
				{
					System.out.println(n+" ");
					n+=2;
				}while(n<=100);
					
			}
		}	


*/