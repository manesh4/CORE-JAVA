
// compile time polymoephism
public class Poly {
	public static int show(int x,int y)
	{
		return x*y;
	}
	public static int show(int n)
	{
		return n*n*n;
	}
	
	public static void main(String[] args) {
		System.out.println("Square = " +show(2,2));
		System.out.println("Cube = " +show(5));


	}

}



/* 
// Run time polymoephism
class Demo {
	public int show(int n)
	{
		return n*n*n;
	}
}
public class Poly extends Demo {
	public int show(int n)
	{
		return n*n;
	}
	
	public static void main(String[] args) {
		Poly p = new Poly();
		System.out.println("Square = " +p.show(2));
		Demo d = new Demo();
		System.out.println("Cube = " +d.show(5));


	}
}

*/