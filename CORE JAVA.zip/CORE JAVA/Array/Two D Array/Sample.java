/* 

public class Sample {
    public static void main(String[] args) {
        
    int a [][] ={{10,20,30},{40,50,60}};

    for(int i=0;i<a.length;i++)
    {
        for(int j=0;j<a[i].length;j++)
        {
            System.out.print("\t "+ a[i][j]);
        }
    }
    }
    
}

*/

/* 

public class Sample {
    public static void main(String[] args) {
        
    int a [][] ={{10,20,30},{40,50,60}};
    int b [][] ={{10,20,30},{40,50,60}};
    int c [][] =new int[2][3];
 
    for(int i=0;i<a.length;i++)
    {
        for(int j=0;j<a[i].length;j++)
        {
            c[i][j]=a[i][j]+b[i][j];
        }
    }
    System.out.println("Addition aaray elements");

for(int i=0;i<a.length;i++)
    {
        for(int j=0;j<a[i].length;j++)
        {
            System.out.print("\t"+ c[i][j]);
        }
        System.out.println();
    }
    }
}

*/


import java.util.Scanner;
public class Sample {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Array element is");
        int a[][] =new int[2][3];

        for(int i=0; i<a.length;i++)
        {
            for(int j=0;j<a[i].length;j++)
            {
                 a[i][j] =sc.nextInt();
            }

        }

        System.out.println("element are");

        for(int i=0; i<a.length;i++)
        {
            for(int j=0;j<a[i].length;j++)
            {
                System.out.print(a[i][j]+" ");
            }
        }
        System.out.println();
    }
}