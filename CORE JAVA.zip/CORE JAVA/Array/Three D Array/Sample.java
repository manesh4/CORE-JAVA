
/* 

public class Sample {
    public static void main(String[] args) {
        int a[][][]={{{10,20},{30,40,50,60},{70,80,90}}};

        System.out.println("Array Element are");

        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a[i].length;j++)
            {
                for(int k=0;k<a[i][j].length;k++)
                {
                    System.out.print("\t"+a[i][j][k]);
                }
            }
            System.out.println();
        }
    }
    
}


*/



import java.util.Scanner;
public class Sample {
    public static void main(String[] args) {

        Scanner Sc = new Scanner(System.in);
        int a[][][]=new int[2][2][2];

        System.out.println("Array Element are");

        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a[i].length;j++)
            {
                for(int k=0;k<a[i][j].length;k++)
                {
                    a[i][j][k]=Sc.nextInt();
            }
            System.out.println();
        }
    }
    System.out.println("Element are");
        for(int i=0;i<a.length;i++)
        {
            for(int j=0;j<a[i].length;j++)
            {
                for(int k=0;k<a[i][j].length;k++)
                {
                   System.out.print("\t"+a[j][j][k]) ;
                }
            }
            System.out.println();
        }
    }
}


