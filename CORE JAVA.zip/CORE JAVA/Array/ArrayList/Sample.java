import java.util.ArrayList;
import java.util.Collection;


public class Sample {
    public static void main(String[] args) {

        ArrayList<Integer>list = new ArrayList<Integer>();
        ArrayList<Integer>list2 = new ArrayList<>();

        //Add element
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(6);

        System.out.println("list element ="+list);

        //To get method
        int element = list.get(0);
        System.out.println(element);

        //Add elememt
        list.add(1,6);
        System.out.println("list element =" +list);

        //Set Element
        list.set(0,0);
        System.out.println("list element =" +list);

        //Delete Element
        list.remove(0);
        System.out.println("list element =" +list);

        //size
        int size = list.size();
        System.out.println("list size =" +size);

        //Loop on list
        for(int i=0;i<list.size();i++)
        {
            System.out.println(list.get(i)+" ");
        }
        System.out.println();

        //Sorting 
        list.add(8);
        list.add(10);
        list.add(9);
        list.add(1);
        list.add(0);

        Collection.sort(list);
        System.out.println("list element=" +list);


    }

    
}
