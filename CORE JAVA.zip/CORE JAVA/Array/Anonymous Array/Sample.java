public class Sample {
    static void sum(int arr[])
    {
        int total = 0;
        for(int i:arr)
        {
            total =total+i;
        }
        System.out.println("total =" +total);
    }
    public static void main(String[] args) {
        Sample.sum(new int[]{10,20,30});
    }
    
}
