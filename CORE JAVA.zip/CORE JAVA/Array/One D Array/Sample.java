/* 
public class Sample {
    public static void main(String[] args) {
        int a[] ={4,5,7,8,9};

       // for(int i=0;i<5;i++)
       // {
        //    System.out.print(a[i]+" ");
      //  }
        for(int i:a)
        {
            System.out.print(i+" ");
        }
    }
    
}
*/

/* 
//Addition of two 1 D array
public class Sample {
    public static void main(String[] args) {
        int a[] ={10,20,30,40,50,};
        int b[] ={1,2,3,4,5};

        int c[] =new int[5];

        for(int i=0;i<5;i++)
        {
            c[i]=a[i]+b[i];
        }
        System.out.println("Addition of two 1 D array is");
        for(int i=0;i<=5;i++)
        {
            System.out.print(c[i]+" ");

        }
    
    }
    
}

*/

/* 
// input user
import java.util.Scanner;

public class Sample {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter array size");
        int size=sc.nextInt();

        int a[]=new int[size];

        System.out.println("Enter Array element");
        for(int i=0; i<a.length;i++)
        {
            a[i]=sc.nextInt();
        }

        System.out.println("Element are");
        for(int i=0; i<a.length;i++)
        {
            System.out.print(a[i]+" ");
        }
    } 
    
}

*/


// user input  addition of two Array
import java.util.Scanner;

public class Sample {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a[]=new int[5];
        int b[]=new int[5];
        int c[]=new int[5];

        System.out.println("Enter 1st Array element");
        for(int i=0; i<a.length;i++)
        {
            a[i]=sc.nextInt();
        }

        System.out.println("Enter 2nd Array element");
        for(int i=0; i<b.length;i++)
        {
            b[i]=sc.nextInt();
        }

        for(int i=0; i<c.length;i++)
        {
            c[i]=a[i]+b[i];
        }


        System.out.println("Addition is");
        for(int i=0; i<a.length;i++)
        {
            System.out.print(c[i]+" ");
        }
    } 
    
}
