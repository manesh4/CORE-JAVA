
/*
// 10 to 1 number print
public class Sample {
	public static void display(int n)
	{
		//base 
		if(n==0)
		{
			return;
		}
		System.out.print(n+" ");
		//recursive function
		display(n-1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display(10);

	}

}
*/

/*
// 1 to 10 number print
public class Sample {
	public static void display(int n)
	{
		//base 
		if(n==11)
		{
			return;
		}
		System.out.print(n+" ");
		//recursive function
		display(n+1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		display(1);

	}

}
*/

/* 
// hello print
public class Sample {
	public static void display()
	{
		System.out.print("hello");
		display();
	}
	public static void main(String[] args) {
	display();
	}

}
*/





/* 
// hello five bar print karne
public class Sample {
	static int no=6;
	public static void display()
	{
		no--;
		if(no>=1)
		{
		System.out.print("hello"+no);
		display();
	}
}
	public static void main(String[] args) {
	display();

	}

}
*/





/* 

//factorial program recursion
public class Sample {
	public static int fact(int no)
	{
		//base 
		if(no==0 || no==1)
		{
			return 1;
		}else {
		return no*fact(no-1);
	}
}
	public static void main(String[] args) {
		int no=5;
		int factorial = fact(no);
		System.out.println(fact (5));

	}

}
*/
