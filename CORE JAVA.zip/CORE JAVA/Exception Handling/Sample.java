
/* 
//Simple program
public class Sample {
    public static void main(String[] args) {
        
        System.out.println(10/2);
        System.out.println(20/2);
        System.out.println(30/2);
        System.out.println(50/2);
        System.out.println(100/2);
        System.out.println(40/2);

    }
    
}
*/

/* 
//Exception program
public class Sample {
    public static void main(String[] args) {
        
        System.out.println(10/2);
        System.out.println(20/2);
        System.out.println(30/2);
        System.out.println(100/0);
        System.out.println(50/2);
        System.out.println(100/2);
        System.out.println(40/2);

    }
    
}

*/

/* 

public class Sample {
    public static void main(String[] args) {

        try{
            int no =100/0;
        }
        catch(ArithmeticException e)
        {
            System.out.println(e);
        }
       // System.out.println(50/2);
    }
}

*/

/* 
// try catch Exception
public class Sample {
    public static void main(String[] args) {

        try{
            int arr[]={1,3,5,7};
            System.out.println(arr[10]);
        }
        catch(ArrayIndexOutOfBoundException e)
        {
            System.out.println(e);
        }
        
       
    }
}

*/

/* 
//finally Excepton
public class Sample {
    public static void main(String[] args) {
        try {
                System.out.println(100/0);
                System.out.println(100/2);
            }
            catch(ArithmeticException e)
            {
                System.out.println("This is Arithmetic Exception");
            }
            finally{
                System.out.println("I m always excuted");
            }
        }
    }

*/


/* 
//throw Exception
public class Sample {
    public static void square(int n)
    {
        if(n<1)
        {
            System.out.println("Plz check no. is not negative");
        }
        else{
            System.out.println("Square is ="+(n*n));
        }
    }

   public static void main(String[] args) {
        //square(2);
        square(-2);
    }
}
*/



//throws Exception
public class Sample {
    public static void divide() throws ArithmeticException
    {
        throw new ArithmeticException("Throwing exception Plz check code");
    }
    public static void main(String[] args) {
        try{
            divide();
        }
        catch(ArithmeticException e)
        {
            System.out.println(" caught in main method");
        }
    }
}