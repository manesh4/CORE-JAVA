/* 
abstract class Vehical {
    abstract void start();
}
class Car extends Vehical {
    void start()
    {
        System.out.println("start with key.....");
    }
}
class Scooter extends Vehical {
    void start()
    {
        System.out.println("start with kick.....");
    }
}
public class Sample {
    public static void main(String[] args) {
        Car c = new Car();
        c.start();
        Scooter s = new Scooter();
        s.start();
    }
}
*/




abstract class Bank {
    abstract int interest();
}
class Icici extends Bank {
    int interest()
    {
        return 7;
       
    }
}
class SBI extends Bank {
    int interest()
    {
        return 6;
    }
}
public class Sample {
    public static void main(String[] args) {
        Icici obj1 = new Icici();
        System.out.println("Rate of interest Icici="+obj1.interest()+ " %");
        SBI obj2 = new SBI();
        System.out.println("Rate of interest SBI="+obj2.interest()+ " %");
    }
}