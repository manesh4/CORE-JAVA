import java.util.*;

public class Practice {
    public static void main(String[] args) {

/* 
        Queue<Integer> queue = new LinkedList<>();
        //Add element
        for(int i=0;i<=5;i++)
        {
            queue.add(i);
        }
        System.out.println(queue);

        //remove front element
        int front=queue.remove();
        System.out.println(front);
        System.out.println(queue);

        //
        queue.add(8);
        int head =queue.peek();
        System.out.println(head);
        System.out.println(queue);

        //Size
        int size =queue.size();
        System.out.println(size);

*/

         Queue<String> queue = new LinkedList<>();
        //Add element
        queue.add("Sprite");
        queue.add("Coca-cola");
        queue.add("Redbull");
        //System.out.println(queue);
        System.out.println("queue ="+queue);
    }
    
}
