interface CNG_car {
    //Abstract Methods
    void drive();
    void cng_kit();
}
interface Petrol_car {
    //Abstract Methods
    void drive();
    void petrol_kit();
}
//Multiple Inheritance
class MultipleInherit implements CNG_car,Petrol_car {
    public void drive()
    {
        System.out.println("Driving a car");
    }
    public void cng_kit()
    {
        System.out.println("car used on cng");
    }
    public void petrol_kit()
    {
        System.out.println("car used on petrol");
    }
}
public class MuiltipleInheritanceWithInterface {
    public static void main(String[] args) {
        MultipleInherit m = new MultipleInherit();
        m.drive();
        m.cng_kit();
        m.petrol_kit();       
    }
    
}
