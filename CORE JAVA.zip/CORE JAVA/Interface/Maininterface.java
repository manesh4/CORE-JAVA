/* 
interface Lang {
    void getName(String name);
}
class Program implements Lang {
    public void getName(String name)
    {
        System.out.println("Current Language = "+name);
    }
}
public class Maininterface {
    public static void main(String[] args) {
        Program p = new Program();
        p.getName("Java");   
    }
}
*/




interface Polygon {
    void getArea(int l,int b);
}
class Rect implements Polygon {
    public void getArea(int l,int b)
    {
        System.out.println("Area of Rect = "+(l*b));
    }
}
public class Maininterface {
    public static void main(String[] args) {
        Rect r = new Rect();
        r.getArea(5,6);   
    }
}