package Inheritance;

class Test {
	void show1()
	{
		System.out.println("Test class show method is called");
	}
}
class Test1 extends Test {
	void show2()
	{
		System.out.println("Test1 class show method is called");
	}
}
public class Hierarchi extends Test  {
	void display()
	{
		System.out.println("Simple class method called");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test1 t1 = new Test1();
		t1.show2();
		t1.show1();
		Hierarchi h = new Hierarchi();
		h.display();
		h.show1();
		

	}

}
