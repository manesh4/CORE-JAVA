
/* 
class Sample {
	void show()
	{
		System.out.println("Parent class show method is called .....");
		System.out.println(2+3);
	}
}
public class Test extends Sample {
	void display()
	{
		System.out.println("Child class show method is called .....");	
	}

	public static void main(String[] args) {
		Test t = new Test();
		t.display();
		t.show();

	}

}
*/



// single inheritance
class Sample {
	void show()
	{
		System.out.println("Parent class show method is called .....");
		System.out.println(2+3);
	}
}
class Sample2 extends Sample {
	void display()
	{
		System.out.println("Child class show method is called .....");	
	}
public class Test {
	public static void main(String[] args) {
		Sample2 t = new Sample2();
		t.display();
		t.show();

	}
}
}


