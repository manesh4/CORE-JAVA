package Inheritance;

class Animals {
	void eat()
	{
		System.out.println("Animals are eating ......!");
	}
}
class Dog extends Animals {
	void sound()
	{
		System.out.println("Dog is sounding ......!");
	}
}
class Cat extends Dog {
	void soundweep()
	{
		System.out.println("Cat is weeping ......!");
	}
}
public class Multilevel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat c = new Cat();
		c.soundweep();
		c.sound();
		c.eat();
	}

}
