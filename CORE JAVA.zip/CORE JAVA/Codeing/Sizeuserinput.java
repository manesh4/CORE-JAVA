import java.util.*;

public class Sizeuserinput {
     public static void main(String[] args) {
          
     
     // user input
     Scanner sc = new Scanner(System.in);
     System.out.println("enter array size");
     int size = sc.nextInt();
    int arr[] = new int[size];
   System.out.println("enter array elements");
   
   for(int i=0;i<arr.length;i++)
   {
       arr[i] = sc.nextInt();
   }
   
    System.out.println("elements are");
   
   for(int i=0;i<arr.length;i++)
   {
       System.out.println(arr[i]+" ");
   }
}
   
}
