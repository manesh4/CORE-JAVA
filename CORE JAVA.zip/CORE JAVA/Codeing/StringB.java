public class StringB {
    public static void main(String[] args) {
        // StringBuilder sb  = new StringBuilder("Java Programing");
        StringBuilder sb  = new StringBuilder("Amit");
        System.out.println(sb);

        //get char
        System.out.println(sb.charAt(0));
        //set char
        sb.setCharAt(0, 'P');
        System.out.println(sb);
        //insert
        sb.insert(0,'A');
        System.out.println(sb);

        sb.delete(1, 2);
        System.out.println(sb);

        sb.append(" Singhaniya");
        System.out.println(sb);

        

    }
}
