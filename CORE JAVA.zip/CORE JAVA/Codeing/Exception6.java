public class Exception6 {

    public static int divide(int n,int m) throws ArithmeticException
    {
        int div = n/m;
        return div;
    }
    public static void main(String[] args) {
        try{
            // System.out.println(divide(10, 0));
            System.out.println(divide(10, 2));
        }
        catch(ArithmeticException e)
        {
            System.out.println("cant divide by zero");
        }

    }
}
