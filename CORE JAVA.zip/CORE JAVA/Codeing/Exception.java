public class Exception {
    public static void main(String[] args) {
        
        System.out.println(10/2);
        System.out.println(100/2);
        System.out.println(50/2);
        System.out.println(15/3);
        System.out.println(10/0);
        System.out.println(10/5);
        System.out.println(20/2);
        System.out.println(30/3);
    }
}
