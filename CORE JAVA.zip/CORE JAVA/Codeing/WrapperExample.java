
public class WrapperExample{
    public static void main(String[] args) {

        //convert int into Integer
        // int a = 5;
        // converting explicitly
        // Integer i = Integer.valueOf(a);
        //autoboxing 
        // Integer j = a;
    // System.out.println(a+" "+i+" "+j);


    //unboxing
        // Integer a = new Integer(5);
        // //explicitly
        // int i = a.intValue(); 
        // //unboxing
        // int j = a; 
        // System.out.println(a+" "+i+" "+j);

//all Wrapper classes

        // byte b = 10;
        // short s = 11;
        // int i=13;
        // long l = 14;
        // float f = 15.0F;
        // double d = 16.0D;
        // char c = 'a';
        // boolean b2 = true;
        // //autoboxing
        // Byte bytewrap = b;
        // Short swrap = s;
        // Integer iwrap = i;
        // Long lwrap = l;
        // Float fwrap = f;
        // Double dwrap = d;
        // Character cwrap = c;
        // Boolean bwrap = b2;
        
        // System.out.println("byte obj = "+bytewrap);
    }
}