import java.util.*;


public class UserArray {
    public static void main(String[] args) {
        
    
    int arr[] = new int[5];
    // user input
    Scanner sc = new Scanner(System.in);
    System.out.println("enter array elements");
    
    for(int i=0;i<arr.length;i++)
    {
        arr[i] = sc.nextInt();
    }
    
     System.out.println("elements are");
    
    for(int i=0;i<arr.length;i++)
    {
        System.out.println(arr[i]+" ");
    }
    }
}
