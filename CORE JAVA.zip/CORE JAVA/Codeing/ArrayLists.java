// import java.util.*;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;;

public class ArrayLists {
    public static void main(String[] args) {
        ArrayList<Integer> list  = new ArrayList<Integer>();


        //add elements
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);

        System.out.println(list);

        //to get element

        int element = list.get(0);
        System.out.println(element);

        //adding element on index position

        list.add(1, 2);
        System.out.println(list);

        //set element
        list.set(0, 0);
        System.out.println(list);

        //delete element

        list.remove(0);
        System.out.println(list);

        //size of list

        int size = list.size();
        System.out.println(size);


        //loops on list

        for(int i=0;i<list.size();i++)
        {
            System.out.print(list.get(i)+" ");
        }
        System.out.println();

        //sorting the list

        list.add(0);
        System.out.println(list);

        Collections.sort(list);
        System.out.println(list);

        // Collections.reverseOrder(list);
        Integer[] ar = {12,12,2,5,6};
        Arrays.sort(ar, Collections.reverseOrder());
        System.out.printf("reverese array = %s",Arrays.toString(ar));


    }
}
