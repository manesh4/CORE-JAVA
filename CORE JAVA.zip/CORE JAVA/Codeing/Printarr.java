// public class Printarr {
//     public static void main(String[] args) {
         
//         int arr[] = {10,20,30,40,50};

//            //for loop
           
//         for(int i=0;i<arr.length;i++)
//         {
//             System.out.println(arr[i]);
//         }
//         // for(int i=0;i<arr.length;i++)
//         // {
//         //     System.out.print(arr[i]+" ");
//         // }

//          // for each loop
//         //  for(int i:arr)
//         //  {
//         //      System.out.print(i+" ");
//         //  }
//     }
// }


// import java.util.*;
// public class MyClass {
//     public static void main(String args[]) {
//         Scanner sc  = new Scanner(System.in);
//      //one-d
//      int arr[] = new int[5];
//      System.out.println("enter elements");
//      for(int i = 0;i<arr.length;i++)
//      {
//          arr[i] = sc.nextInt();
//      }
//      System.out.print("array elemetns are...");
//      for(int i=0;i<arr.length;i++)
//      {
//          System.out.print(arr[i]+" ");
//      }
//     }
// }

// import java.util.*;
// public class MyClass {
//     public static void main(String args[]) {
//         Scanner sc  = new Scanner(System.in);
//              System.out.println("enter array size");
//              int size = sc.nextInt();
//      //one-d
//      int arr[] = new int[size];
//      System.out.println("enter elements");
//      for(int i = 0;i<arr.length;i++)
//      {
//          arr[i] = sc.nextInt();
//      }
//      System.out.print("array elemetns are...");
//      for(int i=0;i<arr.length;i++)
//      {
//          System.out.print(arr[i]+" ");
//      }
//     }
// }