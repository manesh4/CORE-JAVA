
interface Demo{
    int x = 20;
    void getdata();
    }
    class MyClass implements Demo{
        public void getdata()
        {
            System.out.println("value of x = "+x);
        }
    }
     public class Anonymous{

    public static void main(String[] args) {
       MyClass obj = new MyClass();
       obj.getdata();
    }
}
