public class Addition {
   
    public static void main(String args[]) {
        int a[] = {10,20,30};
        int b[] = {40,50,60};
        int c[] = new int[3];
        for(int i=0;i<3;i++)
        {
            c[i] = a[i]+b[i];
        }
        System.out.println("addition of two one d array");
        for(int i=0;i<3;i++)
        {
            System.out.println(c[i]);
        }
    }
}