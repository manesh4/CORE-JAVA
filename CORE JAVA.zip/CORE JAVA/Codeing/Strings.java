public class Strings {
    
    public static void main(String[] args) {
        // char ch[] = {'j','a','v','a'};
        //createing string using new keyword

        // String s = new String(ch);

        //as literals
        // String s = "Java Programing";

        // String s = new String("Java Programing Core Java");
        // System.out.println(s);

        String str  = "   This is Core Java Lectures     ";
   
        System.out.println(str.charAt(0));
        int size = str.length();
        System.out.println(size);

        String name = "Prem";
        String name2 = "Prem";
        String str2 = String.format("Name is = %s", name);
        System.out.println(str2);

        System.out.println(str.substring(2, 12));
        System.out.println(str.substring(2));
        System.out.println(name.equals(name2));
        System.out.println(name.toLowerCase());
        System.out.println(name.toUpperCase());
        System.out.println(str.trim());
        System.out.println(str.indexOf("is"));
        System.out.println(str.isEmpty());
        String str3 = "";
        System.out.println(str3.isEmpty());
    }
}
