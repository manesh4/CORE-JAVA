public class StringBuff {
    public static void main(String[] args) {
        // StringBuffer sb = new StringBuffer(" Hello");
        // System.out.println(sb);

        // sb.insert(0,"java");
        // System.out.println(sb);

        // sb.replace(1, 3, "java");
        // System.out.println(sb);

        // sb.delete(1, 3);
        // System.out.println(sb);

        // sb.reverse();
        // System.out.println(sb);

        //capacity -> it will return the current capacity of the buffer

        // StringBuffer sb = new StringBuffer();
        // System.out.println(sb.capacity());
        // sb.append("hello");
        // System.out.println(sb.capacity());
        // sb.append("java is my favurite language");
        // System.out.println(sb.capacity());
    }
}
