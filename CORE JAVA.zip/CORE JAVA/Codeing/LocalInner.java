public class LocalInner {

    private void getValue()
    {
        int total = 50;
        //local inner class inside method
        class Inner{
            public int div;
            public int rem;

            //making constructor
            public Inner()
            {
                div=5;
                rem = total%div;
            }
            private int getDiv()
            {
                return div;
            }
            private int getRem()
            {
                return total%div;
            }
            private int getQuo()
            {
                return total/div;
            }
        }

        Inner inner = new Inner();
        System.out.println("Div = "+inner.getDiv());
        System.out.println("rem = "+inner.getRem());
        System.out.println("Quo = "+inner.getQuo());
    }
    public static void main(String[] args) {
        LocalInner outer = new LocalInner();
        outer.getValue();
    }
}
