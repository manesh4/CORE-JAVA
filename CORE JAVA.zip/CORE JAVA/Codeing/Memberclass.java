public class Memberclass {
    private int a = 10;

    class Inner{
        void show()
        {
            System.out.println("value of a = "+a);
        }
    }
    public static void main(String[] args) {
        Memberclass m = new Memberclass();
        Memberclass.Inner in = m.new Inner();
        in.show();
        
    }
}
