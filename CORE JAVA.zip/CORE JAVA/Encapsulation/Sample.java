
class Employee {
    //data hiding 
    private int empid;
    
    //setter method
    public void setEmpid(int eid)
    {
        empid=eid;
    }
    // getter method
    public int getEmpid()
    {
        return empid;
    }
public class Sample {
    
    public static void main(String[] args) {
        Employee e = new Employee();
        e.setEmpid(101);
        System.out.println(e.getEmpid());
    }
}
}




/* 


class Area {
    //data hiding 
    int l,b;
    //setter method
    Area(int l,int b)
    {
        this.l=l;
        this.b=b;
    }
    // getter method
    public void getArea()
    {
        int Area = l*b;
        System.out.println("Area =" +Area);
    }
}
public class Sample {
    public static void main(String[] args) {
        Area a = new Area(5,6);
        a.getArea();
    }
}


*/