public class FibonacciSeriesRecursion {
    static int n1=0,n2=1,n3;
    static void printfibonacci(int n)
    {
        if(n>0)
        {
        n3=n1+n2;
        n1=n2;
        n2=n3;
        System.out.println(" "+n3);
        printfibonacci(n-1);
    }
    
}
public static void main(String[] args) {
    int n=10;
    System.out.println(n1+" "+n2);
    printfibonacci(n-2);
    }
}

