public class ReverseNumber {
    public static void main(String[] args) {
        int reverse=0,rem;
        int n =121;
        
		while (n>0)
		{
			rem =n%10;
			reverse = (reverse*10) + rem;
			n=n/10;
		}
		System.out.println(" Reverse Number = " +reverse);
    }
    
}
