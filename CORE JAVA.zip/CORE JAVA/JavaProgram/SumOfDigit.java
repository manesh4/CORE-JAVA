public class SumOfDigit {
    public static void main(String[] args) {
		int sum=0,rem;
        int n =1234;
        
		while (n>0)
		{
			rem =n%10;
			sum = sum + rem;
			n=n/10;
		}
		System.out.println(" sum of digit = " +sum);
    }
    
}
