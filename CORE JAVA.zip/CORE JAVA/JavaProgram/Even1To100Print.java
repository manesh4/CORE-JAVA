public class Even1To100Print {
    public static void main(String[] args) {
/* 
        int n=2;
        do{
            System.out.println(n+" ");
            n+=2;
        }while(n<=100);
*/



         int n=1;
        do{
            System.out.println(n+" ");
            n+=2;
        }while(n<=100);
    }
    
}
