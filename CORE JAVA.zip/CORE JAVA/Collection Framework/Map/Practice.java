import java.util.*;
//import java.util.HashMap;

public class Practice {
public static void main(String[] args) {


/* 
    //HashMap
    HashMap <String,Integer> map = new HashMap<>();

    //insertion
    map.put("India",120);
    map.put("USA",130);
    map.put("China",150);
    System.out.println(map);

    //Duplicate 
    map.put("China",180);
    System.out.println(map);

    //Searching
    if(map.containsKey("China"))
    {
        System.out.println("Key is present");
    }
    else{
        System.out.println("Key is not Present");
    }

    //Get value
    System.out.println(map.get("china"));
    System.out.println(map.get("Singapore"));

    //iteration
    for(Map.Entry<String,Integer> i:map.entrySet())
    {
        System.out.println(i.getKey());
        System.out.println(i.getValue());
    }

    //Set
    Set<String> keys =map.keySet();
    for(String key : keys)
    {
        System.out.println(key+" "+map.get(key));
    }
     
    //Remove
    map.remove("China");
    System.out.println(map);

*/



/* 
    //LinkedHashMap
    Map <String,Integer> map = new LinkedHashMap<>();

    //insertion
    map.put("India",120);
    map.put("USA",130);
    map.put("China",150);
    System.out.println(map);


     //iteration
    for(Map.Entry<String,Integer> i:map.entrySet())
    {
        System.out.println(i.getKey());
        System.out.println(i.getValue());
    }

    */

/* 
    //TreeMap
    Map <String,Integer> map = new TreeMap<>();

    //insertion
    map.put("India",120);
    map.put("USA",130);
    map.put("China",150);
    System.out.println(map);

*/

    //Hashtable
    Map <String,Integer> map = new Hashtable<>();

    //insertion
    map.put("India",120);
    map.put("USA",130);
    map.put("China",150);
    System.out.println(map);

    
}
    
}
