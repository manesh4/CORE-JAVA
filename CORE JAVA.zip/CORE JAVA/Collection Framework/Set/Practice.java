//import java.util.*;
//import java.util.Iterator;
//import java.util.HashMap;
/* 
public class Practice {
    public static void main(String[] args) {
*/
/*      //HashSet

        HashSet<Integer> set = new HashSet<>();
        
        //Add 
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(1);
        set.add(2);
        System.out.println(set);

        //Size
        System.out.println("Size of Set ="+set.size());

        //Search
        if(set.contains(4))
        {
            System.out.println("Present");
        }else{
            System.out.println("Absent");
        }

        //Delete
        set.remove(1);
        System.out.println(set);

        set.add(0);
        set.add(1);
        System.out.println(set);

        //Iterrator
        Iterator it = set.iterator();
        while(it.hasNext());
        {
            System.out.println(it.next()+" ");
        }

*/

/* 
        //LinkedHashSet

        Set<Integer> set = new LinkedHashSet<>();
        
        //Add 
        set.add(1);
        set.add(2);
        set.add(2);
        set.add(1);
        set.add(3);
        System.out.println(set);

*/

/* 
        //HashSet

        Set<Integer> set = new HashSet<>();
        
        //Add 
        set.add(4);
        set.add(2);
        set.add(2);
        set.add(1);
        set.add(3);
        System.out.println(set);

*/
        //TreeSet
/* 
        Set<String> set = new TreeSet<>();
        
        //Add 
        set.add("India");
        set.add("America");
        set.add("Canda");
        
        System.out.println(set);

        set.add("Arjentina");
        System.out.println(set);

*/
/* 
    }
    
}

*/


/* 
//EnumSet
import java.util.*;
import java.util.EnumSet;

enum Demo{code,is,java,lecture};

public class Practice {
    public static void main(String[] args) {
        EnumSet<Demo>set1;
    set1=EnumSet.of(Demo.java,Demo.code,Demo.is,Demo.lecture);
    System.out.println("set 1 ="+set1);
    }
}

*/