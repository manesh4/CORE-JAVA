import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.*;

public class Presist {
    public static void main(String[] args) {
        try{
            //Create object
            Student s1=new Student(122,"java");

            //Create Strim and Writing the object
            FileOutputStream fo = new FileOutputStream("f.txt");
            ObjectOutputStream out = new ObjectOutputStream(fo);

            out.writeObject(s1);
            out.flush();
            out.close();
            System.out.println("success");
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}
