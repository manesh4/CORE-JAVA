
/* 
 // default Constructor
public class Sample {
	int n;
	String name;

	public static void main(String[] args) {
		Sample s = new Sample();
		System.out.println(s.n+"  "s.name);

	}

}
*/


/* 
// No argument  Constructor
public class Sample {
	Sample()
	{
		System.out.println("Argument construtor called ");
		int a=10,b=20;
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		Sample s = new Sample();
	}
}
*/



/* 
//Parameterized  Constructor
public class Sample {
	Sample(int n)
	{
		System.out.println("Parameterized construtor called ");
		System.out.println(n);
	}

	public static void main(String[] args) {
		Sample s = new Sample(5);
	}
}
*/



/*
//Parameterized  Constructor
public class Sample {
	Sample(String str)
	{
		System.out.println("Parameterized construtor called ");
		System.out.println(str);
	}

	public static void main(String[] args) {
		Sample s = new Sample("JAVA");
	}
}

*/

/*
//Parameterized  Constructor
public class Sample {
	Sample(String str,int n)
	{
		System.out.println("Parameterized construtor called ");
		System.out.println(str+"  "+n);
	}

	public static void main(String[] args) {
		Sample s = new Sample("JAVA" 2);
		Sample ss = new Sample("Spring" 3);
	}
}

*/


/* 
//Parameterized  Constructor
public class Sample {
	int empid;
	String name;
	Sample(int eid,String name)
	{
		this.empid =eid;
		this.name = name;
	}
	
	public static void main(String[] args) {
		Sample e1 = new Sample(101,"Shrinath" );
		Sample e2 = new Sample(102,"Pratik");
		Sample e3 = new Sample(103,"Sahil");
		Sample e4 = new Sample(104,"Sumit");
		Sample e5 = new Sample(105,"Kunal");
		
		
		System.out.println("Employee one details = "+e1.empid+"  "+e1.name );
		System.out.println("Employee one details = "+e2.empid+"  "+e2.name );
		System.out.println("Employee one details = "+e3.empid+"  "+e3.name );
		System.out.println("Employee one details = "+e4.empid+"  "+e4.name );
		System.out.println("Employee one details = "+e5.empid+"  "+e5.name );
		
	}
}

*/