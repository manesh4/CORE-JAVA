package Operator;

//public class Test {

//	public static void main(String[] args) {
		// TODO Auto-generated method stub

	




//public class Test {
// public static void main(String[] args) {

/*       
     System.out.println("This is my program");
 }
}
*/

/*  
     int a;
     a=10;
     int b=20;
     int c,d;
     c=30;
     d=40;
     System.out.println("The value of"+a);
     System.out.println("The value of"+(a+b));
     System.out.println("The value of"+b);
     int sub =d-c;
     System.out.println("The subtraction of d and c"+sub);

 }
 
}
*/

/* 
 double pi,area,r;
 pi=3.142;
 r=6.2;
 area=pi*(r*r);
 System.out.println("area ="+area);
}
}
*/

/* 
 int l,b,area;
 l=5;
 b=10;
 area=l*b;
 System.out.println("area ="+area);
}
}

*/

/* 
 int side,area;
 side=5;
 area=side*side;
 System.out.println("area ="+area);
}
}

*/

/* 
 boolean b1,b2;
 b1=true;
 b2=false;
 System.out.println("b1&&b2"+(b1&&b2));
 System.out.println("b1||b2"+(b1||b2));
 System.out.println("!(b1&&b2)"+!(b1&&b2));
 }
}

*/

/* 
int num1,num2;
num1=10;
num2=(num1>5)?100:200;
System.out.println("num2="+num2);
 }
}

*/


//import java.util.*;
//import java.util.Scanner;
//public class Test{
// public static void main(String[] args) {
   //  Scanner sc =new Scanner(System.in);
/* 
     System.out.println("Enter the number:");
     int n = sc.nextInt();
     System.out.println("value ="+n);
 }
}

*/

/* 

System.out.println("Enter float number:");
double f = sc.nextDouble();
System.out.println("value ="+f);
}
}

*/

/* 
System.out.println("Enter the char:");
char c = sc.next().charAt(0);
System.out.println("value ="+c);
}
}

*/

/* 
System.out.println("Enter the String:");
String str = sc.next();
System.out.println("value ="+str);
}
}

*/

/* 
System.out.println("Enter the String:");
String str = sc.nextLine();
System.out.println("value ="+str);
}
}

*/


import java.util.*;
 public class Test{
     public static void main(String[] args) {
         Scanner sc =new Scanner(System.in);
         int num1,num2,total;
         System.out.println("Enter the no:");
         num1  = sc.nextInt();
         System.out.println("Enter the no:");
         num2  = sc.nextInt();
         total = num1+num2;
         System.out.println("The addition of ="+total);

     }
 }
 


